# E-commerce-shopping-portal-using-j2ee-technologies
Create a dynamic e-commerce shopping cart using j2ee technologies like servlets, jsp, JDBC, Jstl, and Java Beans.

### Installing

Just clone the project and import it into your IDE also import the provided sql file(mysql) for the purpose of fetching products from database and storing user details.

I'm using Apache Tomcat as server for deployment purpose.

For jdbc and jstl purposes extract the jars.zip file and copy it to c:-> program files -> Apache Software Foundation -> Tomcat 9.0 -> lib
